drop table Customer CASCADE CONSTRAINTS;
create table Customer(Account_ID NUMBER(10) PRIMARY KEY,customer_name VARCHAR2(50),Email VARCHAR2(30),Address VARCHAR2(100),Pancard VARCHAR2(15));


drop table AccountMaster CASCADE CONSTRAINTS;
create table AccountMaster(Account_ID NUMBER(10) REFERENCES Customer(Account_ID),Account_Type VARCHAR2(25),Account_Balance NUMBER(15),Open_Date DATE);


drop sequence accountId_seq;
create sequence accountId_seq start with 100000000 increment by 1;

alter table Customer add MobileNo varchar2(15);

drop table Transactions CASCADE CONSTRAINTS;
create table Transactions(Transaction_ID NUMBER,Tran_description VARCHAR2(100),DateofTransaction DATE ,TransactionType VARCHAR2(1),TranAmount NUMBER(15),Account_ID NUMBER(10));



drop table ServiceTracker CASCADE CONSTRAINTS;
create table ServiceTracker(Service_ID NUMBER, Service_Description VARCHAR2(100),Account_ID NUMBER REFERENCES Customer(Account_ID), Service_Raised_Date DATE ,Service_status VARCHAR2(20));



drop table UserTable CASCADE CONSTRAINTS;
create table UserTable(Account_ID NUMBER REFERENCES Customer(Account_ID),user_id NUMBER PRIMARY KEY,login_password VARCHAR2(15),secret_question VARCHAR2(50),Transaction_password VARCHAR2(15),lock_status VARCHAR2(1));



drop sequence userId_seq;
create sequence userId_seq start with 102 increment by 1;

drop table Fund_Transfer CASCADE CONSTRAINTS;
create table Fund_Transfer(FundTransfer_ID NUMBER ,Account_ID NUMBER(10) REFERENCES Customer(Account_ID) ,Payee_Account_ID NUMBER(10), Date_Of_Transfer DATE, Transfer_Amount NUMBER(15));



drop table PayeeTable CASCADE CONSTRAINTS;
create table PayeeTable(Account_Id NUMBER(10) REFERENCES Customer(Account_ID) ,Payee_Account_Id NUMBER(10), Nick_name VARCHAR2(15));


CREATE SEQUENCE SERVICE_TRACK START WITH 1000 INCREMENT BY 1;

create sequence payee_seq start with 1000 increment by 1;


