package com.capGemini.banking.service;


import java.util.List;

import com.capGemini.banking.dto.AccountDto;
import com.capGemini.banking.dto.CustomerDto;
import com.capGemini.banking.dto.Fund_Transfer;
import com.capGemini.banking.dto.PayeeTable;
import com.capGemini.banking.dto.ServiceTracker;
import com.capGemini.banking.dto.UserDto;
import com.capGemini.banking.exception.BankingException;

public interface BankingService {
	int addCustDetails(CustomerDto cust,AccountDto acc) throws BankingException;
	 UserDto getUserDto(long accId) throws BankingException;
	 CustomerDto getCustomerDetails(long accId) throws BankingException;
	 boolean updateDetails(CustomerDto customer) throws BankingException;
	 long validateUserId(int userId, String password) throws BankingException;
	 int registerService(ServiceTracker serviceTracker) throws BankingException;
	 boolean registerPayee(PayeeTable payee)throws BankingException;
		List<String> getPayeeIdName(long accountId)throws BankingException;
		public int makeFundTransfer(Fund_Transfer fund) throws BankingException;
		List<Long> getAllAccId(long accId) throws BankingException;
		int isAuthenticated(int id, String password)throws BankingException;
		String ResetPassword(int userid, String oldPass, String newPass)throws BankingException;
}
