package com.capGemini.banking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.jms.Session;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capGemini.banking.dto.AccountDto;
import com.capGemini.banking.dto.CustomerDto;
import com.capGemini.banking.dto.Fund_Transfer;
import com.capGemini.banking.dto.PayeeTable;
import com.capGemini.banking.dto.ServiceTracker;
import com.capGemini.banking.dto.UserDto;
import com.capGemini.banking.exception.BankingException;
import com.capGemini.banking.service.BankingService;
import com.capGemini.banking.service.BankingServiceImpl;

@WebServlet("*.do")
public class BankingController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	CustomerDto cust=new CustomerDto();
	AccountDto acc=new AccountDto();
	UserDto uDto=new UserDto();
BankingService service=new BankingServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}
private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
{
	String path=request.getServletPath();
	HttpSession session=null;
	String nextJsp="errors.jsp";
	String message=null;
	switch(path){
	case "/bank.do":
		response.sendRedirect("UserLogin.html");
		break;
		
		
		
	case "/login.do":
		String password=request.getParameter("password");
		String userid=request.getParameter("userid");
	int id=Integer.parseInt(userid);
	
		System.out.println(password);
		System.out.println(id); 
		int res;
		try {
			res = service.isAuthenticated(id, password);
			
				System.out.println(res);
				if (res == 0) {
					request.setAttribute("errormsg", "oopss 123 wrong password!!!!!! ");
					nextJsp="AdminLogin.jsp";

				}
				if (res == 1) {
					HttpSession session1=request.getSession(true);

				nextJsp="AdminLoginSuccess.jsp";
				}

				if (res == 2) {
					HttpSession session2=request.getSession(true);
					nextJsp="Home.jsp";
				}

				if (res == 3) {

					request.setAttribute("errormsg", "oopss 456 wrong userid!!!!!! ");
					nextJsp="AdminLogin.jsp";

				}
			}
			

		catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		break;
	case "/UserLogin.do":
		
			int userId=Integer.parseInt(request.getParameter("userid"));
			String pass=request.getParameter("password");
			try {
			long accountId=service.validateUserId(userId, pass);
			if(accountId > 0){
				session=request.getSession();
				session.setAttribute("userId",userId);
				session.setAttribute("accountId", accountId);
				nextJsp="UserLoginSuccess.jsp";
			}else{
				nextJsp="errors.jsp";
			}
		} catch (BankingException e2) {
			
			e2.printStackTrace();
		}
		break;
	case "/createaccount.do":
		
		String fullName=request.getParameter("fname");
		String address=request.getParameter("add");
		String mobile=request.getParameter("number");
		String emailid=request.getParameter("email");
		String accType=request.getParameter("saving");
		String openBal=request.getParameter("balance");
		Double openBalDouble=Double.parseDouble(openBal);
		
		cust.setCustomer_name(fullName);
		cust.setAddress(address);
		cust.setMobileNo(mobile);
		cust.setEmail(emailid);
		acc.setAccount_Type(accType);
		acc.setAccount_Balance(openBalDouble);
		
		int accId;
		try {
			accId = service.addCustDetails(cust,acc);
		UserDto	uDto=service.getUserDto(accId);
		System.out.println(uDto);
			if(accId>0)
			{
				
				request.setAttribute("id", accId);
				request.setAttribute("userid", uDto);
				
				nextJsp="AdminLoginSuccess.jsp";
			}
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		break;
		
		
	case "/changePassword.do":
		String oldPass=request.getParameter("old");
		String newPass=request.getParameter("new");
		try {
			
			int uid=Integer.parseInt(request.getQueryString().substring(3));
				
				String status=service.ResetPassword(uid, oldPass, newPass);
				if(status!=null)
				{
					nextJsp="UserLogin.html";
				}
				else
				{
					nextJsp="errors.jsp";
				}
			
				
		}
		catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		break;
		
		
		
		
		
	case "/changeDetails.do":
		Long accId1=Long.parseLong(request.getQueryString().substring(3, 10));//through session
	
		try {
			cust=service.getCustomerDetails(accId1);
			request.setAttribute("address", cust.getAddress());
			request.setAttribute("mobileNo", cust.getMobileNo());
			nextJsp="changeDetails.jsp";
		} catch (BankingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		break;
	case "/updateCustomerDetails.do":
		System.out.println(session);
		
		Long accId2=Long.parseLong(request.getQueryString().substring(3, 10));//through session
		try {
			
		//	System.out.println(session.getAttribute("userName"));
			CustomerDto cust1=new CustomerDto();
			String newAddr=request.getParameter("addr");
			String newMobileNo=request.getParameter("newMob");
			cust1.setAccount_ID(accId2);
			cust1.setAddress(newAddr);
			cust1.setMobileNo(newMobileNo);
			
			boolean flag=service.updateDetails(cust1);
			
			if(flag==true){
				nextJsp="success.jsp";
			}else{
				nextJsp="errors.jsp";
			}
			
		} catch (BankingException e) {
			
			e.printStackTrace();
		}
		
		break;
	case "/acceptChkRequest.do":
		Long accountId=Long.parseLong(request.getQueryString().substring(3, 10));
		String option=request.getParameter("request");
		System.out.println(option);
		if(option.equals("yes")){
		ServiceTracker tracker=new ServiceTracker();
		tracker.setAccountId(accountId);
		tracker.setServiceDescription("Cheque Book Request");
		try {
			int serviceId=service.registerService(tracker);
			System.out.println(serviceId);
			nextJsp="success.jsp";
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}else{
			nextJsp="chequeReq.jsp";
		}
		break;
	case "/chequeReq.do":
		
		nextJsp="chequeReq.jsp";
		
	break;
		
	case "/addPayee.do":
		Long accountId1=Long.parseLong(request.getQueryString().substring(3, 10));
		Long payeeAcc=Long.parseLong(request.getParameter("accNo"));
		String nickName=request.getParameter("nickName");
		PayeeTable payee=new PayeeTable();
		payee.setAccountId(accountId1);
		payee.setPayeeAccId(payeeAcc);
		payee.setNickName(nickName);
		
		try {
			boolean flag=service.registerPayee(payee);
			if(flag==true){
				message="Payee is registered SuccessFully";
				request.setAttribute("message", message);
				nextJsp="success.jsp";
				
			}else{
				nextJsp="errors.jsp";
			}
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		break;
	
	case "/transferToElse.do":
		Long accountId2=Long.parseLong(request.getQueryString().substring(3, 10));
		try {
			List<String> payeeList=service.getPayeeIdName(accountId2);
			request.setAttribute("payeeList", payeeList);
			nextJsp="transferToElse.jsp";
			
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		break;
	case "/transferFundProcess.do":
		Long accountId3=Long.parseLong(request.getQueryString().substring(3, 10));
			long payeeAccNo=Long.parseLong(request.getParameter("to").substring(0, 10));
			double amount=Double.parseDouble(request.getParameter("amt"));
			Fund_Transfer fund=new Fund_Transfer();
			fund.setAccountId(accountId3);
			fund.setTransfer_amount(amount);
			fund.setPayeeAccId(payeeAccNo);
		try {
			int transferId=service.makeFundTransfer(fund);
			request.setAttribute("message", "Transaction Successful");
			nextJsp="success.jsp";
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		break;
		
	case "/transferToOwn.do":
		long accNo=Long.parseLong(request.getQueryString().substring(3, 10));
		try {
			List<Long> senderAccList=service.getAllAccId(accNo);
			senderAccList.add(accNo);
			List<Long> recieverAccList=service.getAllAccId(accNo);
			
			request.setAttribute("sender", senderAccList);
			request.setAttribute("reciever", recieverAccList);
			nextJsp="transferToOwn.jsp";
			
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		break;
	case "/transferToOwnProcess1.do":
		
		long senderAcc=Long.parseLong(request.getParameter("from"));
		long recieverAcc=Long.parseLong(request.getParameter("to"));
		double amt=Double.parseDouble(request.getParameter("amt"));
		Fund_Transfer fund1=new Fund_Transfer();
		fund1.setAccountId(senderAcc);
		fund1.setPayeeAccId(recieverAcc);
		fund1.setTransfer_amount(amt);
		
		try {
			int transferId1=service.makeFundTransfer(fund1);
			
			if(transferId1>0){
				nextJsp="success.jsp";
			}
			else{
				nextJsp="welcome.jsp";
			}
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		break;
		
	}
	RequestDispatcher dispatch2=request.getRequestDispatcher(nextJsp);
	dispatch2.forward(request, response);

}
}
