package com.capGemini.banking.dto;

public class PayeeTable {

	private long accountId;
	private long payeeAccId;
	private String nickName;
	public PayeeTable() {
		// TODO Auto-generated constructor stub
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public long getPayeeAccId() {
		return payeeAccId;
	}
	public void setPayeeAccId(long payeeAccId) {
		this.payeeAccId = payeeAccId;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
}
