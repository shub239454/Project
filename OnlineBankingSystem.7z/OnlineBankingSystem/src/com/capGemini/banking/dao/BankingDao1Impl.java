package com.capGemini.banking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capGemini.banking.dto.Fund_Transfer;
import com.capGemini.banking.dto.PayeeTable;
import com.capGemini.banking.dto.ServiceTracker;
import com.capGemini.banking.exception.BankingException;
import com.capGemini.banking.util.BankingUtil;

public class BankingDao1Impl implements BankingDao1{

	@Override
	public int registerService(ServiceTracker serviceTracker)
			throws BankingException {
		Connection con=null;
		PreparedStatement ps=null;
		int serviceId=getServiceId();
		String qry="INSERT INTO SERVICETRACKER VALUES(?,?,?,sysdate,?)";
		con=BankingUtil.obtainConnection();
		try {
			ps=con.prepareStatement(qry);
			ps.setInt(1,serviceId);
			ps.setString(2, serviceTracker.getServiceDescription());
			ps.setLong(3, serviceTracker.getAccountId());
			ps.setString(4, serviceTracker.getServiceStatus());
			int c=ps.executeUpdate();
			if(c>0){
				return serviceId; 
			}
		} catch (SQLException e) {
			throw new BankingException("JDBC Failed",e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				if(con != null){
					con.close();
				}
			} catch (SQLException e) {
				throw new BankingException("Problem in closing connection",e);
			}
		}
		
		return 0;
	}
	
	public int getServiceId() throws BankingException {
		Connection con=null;
		PreparedStatement ps=null;
		int userId = 0;
		String query = "SELECT SERVICE_TRACK.NEXTVAL from dual";
		try {
			con = BankingUtil.obtainConnection();
			ps = con.prepareStatement(query);
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				userId = res.getInt(1);
			}
		} catch (SQLException e) {

			throw new BankingException("JDBC Failed",e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				if(con != null){
					con.close();
				}
			} catch (SQLException e) {
				throw new BankingException("Problem in closing connection",e);
			}
		}

		return userId;
	}

	public int getFundTransferId() throws BankingException {
		Connection con=null;
		PreparedStatement ps=null;
		int userId = 0;
		String query = "SELECT payee_seq.NEXTVAL from dual";
		try {
			con = BankingUtil.obtainConnection();
			ps = con.prepareStatement(query);
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				userId = res.getInt(1);
			}
		} catch (SQLException e) {
			throw new BankingException("JDBC Failed",e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				if(con != null){
					con.close();
				}
			} catch (SQLException e) {
				throw new BankingException("Problem in closing connection",e);
			}
		}
		return userId;
	}
	@Override
	public boolean registerPayee(PayeeTable payee) throws BankingException {
		
		Connection con=null;
		PreparedStatement ps=null;
		String qry="INSERT INTO PAYEETABLE VALUES(?,?,?)";
		con=BankingUtil.obtainConnection();
		try {
			ps=con.prepareStatement(qry);
			ps.setLong(1, payee.getAccountId());
			ps.setLong(2, payee.getPayeeAccId());
			ps.setString(3, payee.getNickName());
			int c=ps.executeUpdate();
			if(c>0){
				return true;
			}
			
		} catch (SQLException e) {
			throw new BankingException("JDBC Failed",e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				if(con != null){
					con.close();
				}
			} catch (SQLException e) {
				throw new BankingException("Problem in closing connection",e);
			}
		}
		
		
		return false;
	}

	@Override
	public List<String> getPayeeIdName(long accountId) throws BankingException {
		Connection con=null;
		PreparedStatement ps=null;
		
		String query = "SELECT PAYEE_ACCOUNT_ID,NICK_NAME FROM PAYEETABLE WHERE ACCOUNT_ID=?";
		try {
			con = BankingUtil.obtainConnection();
			ps = con.prepareStatement(query);
			ps.setLong(1, accountId);
			ResultSet res = ps.executeQuery();
			List<String> payeeIdName=new ArrayList<String>();
			while (res.next()) {
				String nickName=res.getString("NICK_NAME");
				long payeeAcc=res.getLong("PAYEE_ACCOUNT_ID");
				
				String pIdName=String.valueOf(payeeAcc)+nickName;
				payeeIdName.add(pIdName);
				
			}
			return payeeIdName;
		} catch (SQLException e) {
			throw new BankingException("JDBC Failed",e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				if(con != null){
					con.close();
				}
			} catch (SQLException e) {
				throw new BankingException("Problem in closing connection",e);
			}
		}
		
	}

	@Override
	public int makeFundTransfer(Fund_Transfer fund) throws BankingException {
		
		Connection con=null;
		PreparedStatement ps=null;
		String qry="INSERT INTO FUND_TRANSFER VALUES(?,?,?,SYSDATE,?)";
		con=BankingUtil.obtainConnection();
		int transId=getFundTransferId();
		try {
			ps=con.prepareStatement(qry);
			ps.setLong(1,transId);
			ps.setLong(2, fund.getAccountId());
			ps.setLong(3, fund.getPayeeAccId());
			ps.setDouble(4, fund.getTransfer_amount());
			int c=ps.executeUpdate();
			if(c>0){
				return transId;
			}
			
		} catch (SQLException e) {
			throw new BankingException("JDBC Failed",e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				if(con != null){
					con.close();
				}
			} catch (SQLException e) {
				throw new BankingException("Problem in closing connection",e);
			}
		}
		return 0;
	}

	@Override
	public double getBalance(long accountId) throws BankingException {
		Connection con=null;
		PreparedStatement ps=null;
		double userId = 0.0;
		String query = "SELECT ACCOUNT_BALANCE FROM ACCOUNTMASTER WHERE ACCOUNT_ID=?";
		try {
			con = BankingUtil.obtainConnection();
			ps = con.prepareStatement(query);
			ps.setLong(1, accountId);
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				userId = res.getInt("ACCOUNT_BALANCE");
			}
		} catch (SQLException e) {
			throw new BankingException("JDBC Failed",e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				if(con != null){
					con.close();
				}
			} catch (SQLException e) {
				throw new BankingException("Problem in closing connection",e);
			}
		}
		
		return 0;
	}
	
	@Override
	public List<Long> getAllAccId(long accId)throws BankingException{
		
		Connection con=null;
		PreparedStatement ps=null;
		
		String query = "SELECT ACCOUNT_ID FROM ACCOUNTMASTER";
		try {
			con = BankingUtil.obtainConnection();
			ps = con.prepareStatement(query);
			List<Long> accList =new ArrayList<Long>();
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				if(accId == res.getLong("ACCOUNT_ID")){
					continue;
				}
				accList.add(res.getLong("ACCOUNT_ID"));
			}
			return accList;
		} catch (SQLException e) {
			throw new BankingException("JDBC Failed",e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				if(con != null){
					con.close();
				}
			} catch (SQLException e) {
				throw new BankingException("Problem in closing connection",e);
			}
		}
						
	}
	
	@Override
	public String ResetPassword(int userid,String oldPass,String newPass) throws BankingException
	{
		Connection conn=null;
		PreparedStatement ps=null;
		conn = BankingUtil.obtainConnection();
		System.out.println("conn");
		
		String query="select Login_Password from UserTable where User_Id=?";
		try {
			ps = conn.prepareStatement(query);
			ps.setInt(1, userid);
			ResultSet rs=ps.executeQuery();
			
			String pass=null;
			while(rs.next())
			{
				pass=rs.getString("Login_Password");
			}
			if(oldPass.equals(pass))
			{
				
				String query2="Update UserTable set Login_Password=? where User_Id=?";
				ps = conn.prepareStatement(query2);
					ps.setString(1,newPass);
					ps.setInt(2, userid);
					int success=ps.executeUpdate();
					System.out.println(success);
					System.out.println(newPass+"of fuction");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return newPass;
		
		
	}
	

}
