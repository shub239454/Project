package com.capGemini.banking.dao;

import java.util.List;

import com.capGemini.banking.dto.Fund_Transfer;
import com.capGemini.banking.dto.PayeeTable;
import com.capGemini.banking.dto.ServiceTracker;
import com.capGemini.banking.exception.BankingException;

public interface BankingDao1 {
	
	int registerService(ServiceTracker serviceTracker) throws BankingException;
	boolean registerPayee(PayeeTable payee)throws BankingException;
	List<String> getPayeeIdName(long accountId)throws BankingException;
	
	int makeFundTransfer(Fund_Transfer fund) throws BankingException;
	double getBalance(long accountId)throws BankingException;
	List<Long> getAllAccId(long accId) throws BankingException;
	String ResetPassword(int userid, String oldPass, String newPass)throws BankingException;
}
