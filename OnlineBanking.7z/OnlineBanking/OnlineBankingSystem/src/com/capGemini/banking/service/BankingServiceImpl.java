package com.capGemini.banking.service;

import com.capGemini.banking.dao.BankingDao;
import com.capGemini.banking.dao.BankingDaoImpl;
import com.capGemini.banking.dto.AccountDto;
import com.capGemini.banking.dto.CustomerDto;
import com.capGemini.banking.dto.UserDto;
import com.capGemini.banking.exception.BankingException;

public class BankingServiceImpl implements BankingService {
BankingDao bankDao;
	public BankingServiceImpl() {
		bankDao=new BankingDaoImpl();
	}

	

	


	@Override
	public int addCustDetails(CustomerDto cust, AccountDto acc)
			throws BankingException {
		return bankDao.addCustDetails(cust,acc);
	}






	@Override
	public UserDto getUserDto(long accId) throws BankingException {
		
		return bankDao.getUserDto(accId);
	}

}
